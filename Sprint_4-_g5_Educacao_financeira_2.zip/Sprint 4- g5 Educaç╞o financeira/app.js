var db_contatos_inicial = {
    "data": [
               {
            "id": 1,
            "nome": "Osvaldo Silva",            
            "email": "Osilvadop@gmail.com",
            "telefone": "68",
            "a": "Gostei do site achei ele comum, mas queria que fosse mais proximo."
        },
        {
            "id": 2,
            "nome": "Mariana Costa",
            "email": "Marian5leite@hotmial.com",
            "telefone": "62",
            "a": "Achei interessante a ideia de conectar outros site para explicar as coisas ficando mais facil de encontrar."
        }, 
                 
    ]
}

var db = JSON.parse(localStorage.getItem('db_contato'));
if (!db) {
    db = db_contatos_inicial
};

function displayMessage(msg) {
    $('#msg').html('<div class="alert alert-warning">' + msg + '</div>');
}

function insertContato(contato) {
    let novoId = 1;
    if (db.data.length != 0) 
      novoId = db.data[db.data.length - 1].id + 1;
    let novoContato = {
        "id": novoId,
        "nome": contato.nome,
        "email" : contato.email,
        "telefone": contato.telefone,
        "a": contato.a,
        
    };

    db.data.push(novoContato);
    displayMessage("Contato inserido com sucesso");

    localStorage.setItem('db_contato', JSON.stringify(db));
}

function updateContato(id, contato) {
    let index = db.data.map(obj => obj.id).indexOf(id);

    db.data[index].nome = contato.nome,
    db.data[index].email = contato.email,
    db.data[index].telefone = contato.telefone,
    db.data[index].a = contato.a,
    

    displayMessage("Contato alterado com sucesso");

    localStorage.setItem('db_contato', JSON.stringify(db));
}

function deleteContato(id) {    
    db.data = db.data.filter(function (element) { return element.id != id });

    displayMessage("Contato removido com sucesso");

    localStorage.setItem('db_contato', JSON.stringify(db));
}