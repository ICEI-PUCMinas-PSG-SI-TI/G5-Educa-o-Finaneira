var db_contatos_inicial = {
    "data": [
        {
            "id": 1,
            "nome": "Thiago Akihiro",            
            "email": "aki@gmail.com",
            "telefone": "1-770-736-8031",
            "website": "Exemplo oi"
        },
        {
            "id": 2,
            "nome": "Henrique Carrara",
            "email": "haru@gmail.com",
            "telefone": "010-692-6593",
            "website": "Deu certo?"
        },
        {
            "id": 3,
           "nome": "Marcos Noronha",            
            "email": "fuyu@gmail.com",
            "telefone": "1-463-123-4447",
            "website": "Achei legal"
        },
        {
            "id": 4,
            "nome": "Augusto silva",            
            "email": "natsu@gmail.com",
            "telefone": "493-170-9623 x156",
            "website": "Cansativo"
        },
        {
            "id": 5,
           "nome": "Wander Buzatti",            
            "email": "keitai@gmail.com",
            "telefone": "(254)954-1289",
            "website": "Estou sem ideia"
        },
        {
            "id": 6,
            "nome": "Pedro Castro",            
            "email": "mizu@gmail.com",
            "telefone": "1-477-935-8478",
            "website": "Quero ferias"
        },
        {
            "id": 7,
            "nome": "Cleusa Aparecida",            
            "email": "hono@gmail.com",
            "telefone": "210.067.6132",
            "website": "Quero ganhar mais Dinheiro"
        },
        {
            "id": 8,
            "nome": "Vonder Junior",            
            "email": "kaze@gmail.com",
            "telefone": "586.493.6943",
            "website": "Quero um final de semana sem precupar com trabalho"
        },
        {
            "id": 9,
            "nome": "Victor Marcel",            
            "email": "kaminari@gmail.com",
            "telefone": "(775)976-6794",
            "website": "Porque tem duas provas quinta"
        },
        {
            "id": 10,
            "nome": "Fernanda Aiko",            
            "email": "tsuchi@gmail.com",
            "telefone": "024-648-3804",
            "website": "Quero viajar sem preocupar com financeiro"
        }
    ]
}

var db = JSON.parse(localStorage.getItem('db_contato'));
if (!db) {
    db = db_contatos_inicial
};

function displayMessage(msg) {
    $('#msg').html('<div class="alert alert-warning">' + msg + '</div>');
}

function insertContato(contato) {
    let novoId = 1;
    if (db.data.length != 0) 
      novoId = db.data[db.data.length - 1].id + 1;
    let novoContato = {
        "id": novoId,
        "nome": contato.nome,
        "email" : contato.email,
        "telefone": contato.telefone,
       
        "website": contato.website
    };

    db.data.push(novoContato);
    displayMessage("Contato inserido com sucesso");

    localStorage.setItem('db_contato', JSON.stringify(db));
}

function updateContato(id, contato) {
    let index = db.data.map(obj => obj.id).indexOf(id);

    db.data[index].nome = contato.nome,
    db.data[index].email = contato.email,
    db.data[index].telefone = contato.telefone,   
    db.data[index].website = contato.website

    displayMessage("Contato alterado com sucesso");

    localStorage.setItem('db_contato', JSON.stringify(db));
}

function deleteContato(id) {    
    db.data = db.data.filter(function (element) { return element.id != id });

    displayMessage("Contato removido com sucesso");

    localStorage.setItem('db_contato', JSON.stringify(db));
}